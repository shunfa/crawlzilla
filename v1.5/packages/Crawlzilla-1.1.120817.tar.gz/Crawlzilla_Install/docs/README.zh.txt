Readme v0.3

有關最新信息CrawlZilla，請訪問我們的網站：

 * English：
    http://sf.net/p/crawlzilla

 * 中文：
    http://code.google.com/p/crawlzilla/

如何安裝：
    1. 下載最新的包CrawlZilla然後提取它。
    2. 在這個目錄中，鍵入
       ./install
    3. 跟隨幾個提示，輸入正確的信息，即可完成安裝步驟。

如何使用與管理：
    * 網頁操控端: 用瀏覽器造訪 http://Crawlzilla_Server_IP:8080/
    * 終端機管控平台: 在終端機內輸入指令=>  crawlzilla

如何移除：
    * 在終端機內輸入指令=> ./crawlzilla_remove



您可以訪問我們的網站，以得到更詳細的信息。
