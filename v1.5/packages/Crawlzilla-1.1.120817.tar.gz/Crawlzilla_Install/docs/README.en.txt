Readme v 0.3

For the latest information about CrawlZilla, please visit our website at:

 * English:
    http://sf.net/p/crawlzilla

 * Chinese:
    http://crawlzilla.info/
    ( http://code.google.com/p/crawlzilla/ )

Installation HowTo:
    1. Download CrawlZilla newest package then extract it.
    2. On that directory, type "./install" 
    3. Follewing several hints and input correct information, you have finished.

Managemant HowTo :
    * Web : visit http://Crawlzilla_Server_IP:8080/
    * Terminal : type the following command : crawlzilla

Remove HowTo :
    type the following command : crawlzilla_remove


You can visit our website for more detail information.

