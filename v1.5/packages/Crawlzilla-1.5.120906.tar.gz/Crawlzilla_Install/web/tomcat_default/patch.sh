#!/bin/bash

#default/WEB-INF/classes/org/nutch/jsp/search_zh.properties
#default/zh
##  about.html
##  help.html
##  include/header.html
##  search.html
#default/img/reiter
##  nchc_logo.jpg
##  robots.gif
##  logo_nutch.gif


cp ./patch/* /opt/crawlzilla/tomcat/webapps/default/
